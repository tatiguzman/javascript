function showName(str){

    if (str.length === 0){ //sale de la función si no se ha escrito nada en el input

        document.getElementById("txtName").innerHTML=""; //limpia los resultados previos

        return;

    }

    if (window.XMLHttpRequest) {// código para IE7+, Firefox, Chrome, Opera, Safari

        xmlhttp=new XMLHttpRequest();

    } else {// código para IE6, IE5

        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

    }

    xmlhttp.onreadystatechange=function() {

        if (xmlhttp.readyState === 4 && xmlhttp.status === 200){ // Chequeamos que la solicitud está finalizada y la respuesta está lista, y el status es OK

            document.getElementById("txtName").innerHTML=xmlhttp.responseText; // Definimos la respuesta como HTML interior del elemento cuyo ID es "txtName"

        }

    }

    // El método open() inicializa una solicitud recién creada o reinicializa una existente. En este caso, hace un pedido por GET con el valor del string de nuestro input

    xmlhttp.open("GET","nombres.php?name="+str,true);

    // El método send() envía la solicitud al servidor

    xmlhttp.send();

}