<html>

<head>

    <title>Buscador de nombres</title>

    <script type="text/javascript" src="auto_complete.js"></script>

</head>

<body>

<h2>Buscador de nombres</h2>

<p><b>Escribe la primer letra del nombre</b></p>

<!-- Creamos un formulario que luego de tipear cada caracter llama a la función showName, pasándole como parámetro lo que hayamos tipeado en el input -->

<form method="POST" action="index.php">

    <p><input type="text" size="40" id="txtHint"  onkeyup="showName(this.value)"></p>

</form>

<!-- Creamos un párrafo donde vamos a mostrar los resultados -->

<p>Resultados: <span id="txtName"></span></p>

</body>

</html>