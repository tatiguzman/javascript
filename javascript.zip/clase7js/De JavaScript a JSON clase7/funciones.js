addEventListener('load',inicializarEventos);

function inicializarEventos()
{
  var ref=document.getElementById('boton1');
  ref.addEventListener('click',mostrarConversion);
}
//En esta función convierto de ObjetoJavaScript a JSON
function mostrarConversion(e)
{
  var obj={
    nombre:'Daniel Fuentes',
    edad:51,
    sueldos:[15000,12000,21000]
  };

  
  var cadena = JSON.stringify(obj);
  alert(cadena);
  
}