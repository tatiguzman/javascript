window.onload=function(){
	//1
	var titular = document.getElementById("titular");
	titular.style.display = "none";
	
	// Ejercicio 2
	var imagen = document.querySelector("img");
	imagen.style.filter = "grayscale(100%)";

	//Ejercicio 3
	var inputs = document.querySelectorAll("input");
	inputs.forEach(function(elemento){
    elemento.style.background = "red";
	});

	// DOM

	// Ejercicio 1 
	var copyright = document.getElementById("copyright")
	console.log(copyright.attributes);

	// ELEMENTOS

	// Ejercicio 1
	var botonAbracadabra = document.getElementById("abracadabra");
	var nuevoBoton = document.createElement("a");
	nuevoBoton.innerHTML = "Desaparece";
	nuevoBoton.id = "desaparece";
	nuevoBoton.className = "button big scrolly";
	var parent = botonAbracadabra.parentNode;
	parent.appendChild(nuevoBoton);

	
	var lechuza = document.getElementById("lechuza");
	nuevoBoton.onclick = function(){
    lechuza.style.display = "none";
	};

	botonAbracadabra.onclick = function(){
    	lechuza.style.display = "block";
	};

 
	// Ejercicio 2
	document.getElementById("top").textContent = "Esto es TOP";
	document.getElementById("work").textContent = "Esto es WORK";
	document.getElementById("portfolio").textContent = "Esto es PORTFOLIO";
	document.getElementById("contact").textContent = "Esto es CONTACT"

	// Ejercicio 3
	var caja1 = document.getElementById("caja1");
	caja1.querySelector("h3").textContent = "Soy la caja 1";
	caja1.querySelector("p").textContent = "Soy el parrafo de la caja 1";
	caja1.querySelector("a").setAttribute("href", "http://www.sprint3nomegusto.com.ar/coni");
	caja1.querySelector("img").setAttribute("src", "https://media.giphy.com/media/fDO2Nk0ImzvvW/giphy.gif");
}